var dom = document.getElementById('hangye97-19');
    var myChart = echarts.init(dom, null, {
      renderer: 'canvas',
      useDirtyRect: false
    });
    var app = {};
    
    var option;

    const labelRight = {
  position: 'right'
};
option = {
  title: {
    text: '分行业97年到19年碳排放占比变化图'
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow'
    }
  },
  grid: {
    top: 80,
    bottom: 30
  },
  xAxis: {
    type: 'value',
    position: 'top',
    splitLine: {
      lineStyle: {
        type: 'dashed'
      }
    }
  },
  yAxis: {
    type: 'category',
    axisLine: { show: false },
    axisLabel: { show: false },
    axisTick: { show: false },
    splitLine: { show: false },
    data: [
      '电力、蒸汽、热水的生产和供应',
      '黑色金属冶炼和压制',
      '非金属矿产',
      '运输、仓储、邮电服务',
      '化学原料及化学制品',
      '石油加工和焦化',
      '农、林、牧、渔业、水利',
      '煤炭开采选矿',
      '批发、零售贸易及餐饮服务',
      '有色金属冶炼和压延',
      '石油和天然气开采',
      '食品加工',
      '纺织工业',
      '造纸及纸制品',
      '建设',
      '普通机械',
      '粮食生产',
      '饮料生产',
      '运输设备',
      '金属制品'
    ]
  },
  series: [
    {
      name: 'Cost',
      type: 'bar',
      stack: 'Total',
      label: {
        show: true,
        formatter: '{b}'
      },
      data: [
        0.102735418,
        0.066614023,
        { value: -0.021327833, label: labelRight },
        0.030250453,
        { value:-0.032044404, label: labelRight },
        0.000919062,
        { value: -0.016101918, label: labelRight },
        { value: -0.009522134, label: labelRight },
        { value: -0.002236481, label: labelRight },
        { value: -0.00185176, label: labelRight },
        { value: -0.008597693, label: labelRight },
        { value: -0.006070955, label: labelRight },
        { value: -0.01024172, label: labelRight },
        { value: -0.007198832, label: labelRight },
        { value: -0.000721561, label: labelRight },
        { value: -0.006511192, label: labelRight },
        { value: -0.003119527, label: labelRight },
        { value: -0.002877216, label: labelRight },
        { value:-0.004247438, label: labelRight },
        { value:-0.001307925, label: labelRight },


      ]
    }
  ]
};

    if (option && typeof option === 'object') {
      myChart.setOption(option);
    }

    window.addEventListener('resize', myChart.resize);