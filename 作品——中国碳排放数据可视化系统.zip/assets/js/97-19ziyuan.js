var dom = document.getElementById('ziyuan97-19');
    var myChart = echarts.init(dom, null, {
      renderer: 'canvas',
      useDirtyRect: false
    });
    var app = {};
    
    var option;

    const labelRight = {
  position: 'right'
};
option = {
  title: {
    text: '分资源97年到19年碳排放占比变化图'
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow'
    }
  },
  grid: {
    top: 80,
    bottom: 30
  },
  xAxis: {
    type: 'value',
    position: 'top',
    splitLine: {
      lineStyle: {
        type: 'dashed'
      }
    }
  },
  yAxis: {
    type: 'category',
    axisLine: { show: false },
    axisLabel: { show: false },
    axisTick: { show: false },
    splitLine: { show: false },
    data: [
      '原煤',
      '精煤',
      '其他洗煤',
      '加工成煤',
      '焦炭',
      '焦煤炉气',
      '其他气体',
      '其他焦化产品',
      '原油',
      '汽油',
      '汽油',
      '煤油',
      '柴油',
      '燃油',
      '液化石油气',
      '炼厂气',
      '其他石油产品',
      '天然气'
    ]
  },
  series: [
    {
      name: 'Cost',
      type: 'bar',
      stack: 'Total',
      label: {
        show: true,
        formatter: '{b}'
      },
      data: [
        { value: -0.110621941, label: labelRight },
        { value:-0.010809126, label: labelRight },
        0.00823261,
        0.002902544,
        0.029049119,
        0.002110249,
        0.063542404,
        0.000565741,
        { value: -0.004927113, label: labelRight },
        0.006945381,
        0.005147381,
        { value: -0.009745785, label: labelRight },
        { value: -0.033070814, label: labelRight },
        0.00308832,
        0.000936601,
        0.001891518,
        0.032456802

      ]
    }
  ]
};

    if (option && typeof option === 'object') {
      myChart.setOption(option);
    }

    window.addEventListener('resize', myChart.resize);