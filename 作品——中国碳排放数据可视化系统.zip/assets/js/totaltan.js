var dom = document.getElementById("totaltan");
var myChart = echarts.init(dom);
var app = {};

var option;



option = {
  tooltip: {
    trigger: 'axis',
    position: function (pt) {
      return [pt[0], '10%'];
    }
  },
  title: {
    left: 'center',
    text: '1997-2019 总碳排放量'
  },
  toolbox: {
    feature: {
      dataZoom: {
        yAxisIndex: 'none'
      },
      restore: {},
      saveAsImage: {}
    }
  },
  xAxis: {
    
    boundaryGap: false,
    data:[1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019]
  },
  yAxis: {
    type: 'value',
    boundaryGap: [0, '70%']
  },
  dataZoom: [
    {
      type: 'inside',
      start: 0,
      end:100
    },
    {
      start: 0,
      end:20
    }
  ],
  series: [
    {
      name: '碳排放量',
      type: 'line',
      smooth: true,
      // symbol: 'none',
      areaStyle: {},
      data:[2924,2886,2879,3003,3250,3472,4054,4696,5398,6009,6546,6761,7334,7905,8742,9081,9534,9451,9254,9256,9408,9621,9795]
    }
  ]
};

if (option && typeof option === 'object') {
    myChart.setOption(option);
}