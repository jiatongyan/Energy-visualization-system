var dom = document.getElementById("resources97");
var myChart = echarts.init(dom);
var app = {};

var option;




option = {
  title: {
    text: '1997年分资源碳排放量图',
    x: 'center', // x 设置水平安放位置
    y: 'top', // y 设置垂直安放位置为全图顶端
    backgroundColor: '#EEE', // 主标题文本样式设置
    textStyle: {
      fontSize: 26,
      fontWeight: 'bolder',
      color: '#000080'
    }
  },
  legend: {
    top: 'bottom',
    textStyle: {
      fontSize: 17
    }
  },
  toolbox: {
    show: true,
    feature: {
      mark: { show: true },
      dataView: { show: true, readOnly: false },
      restore: { show: true },
      saveAsImage: { show: true }
    }
  },
  tooltip: {
    show: true,
    trigger: 'item', // trigger 设置触发类型，默认数据触发
    showDelay: 20, // 显示延迟，避免频繁切换，单位ms
    hideDelay: 20, // 隐藏延迟，单位ms
    backgroundColor: 'rgba(255,255,255,0.8)', //设置提示框背景颜色
    color: 'black',
    borderWidth: '1', //边框宽度设置1
    borderColor: 'gray', //设置边框颜色
    textStyle: {
      fontSize: '16px',
      color: '#000' // 设置文本颜色 默认#FFF
    },
    formatter: '{a}<br/> {b} : {c} ({d}%)' //
  },
  series: [
    {
      name: '碳排放量',
      type: 'pie',
      radius: ['15%', '75%'], // 设置环形饼状图， 第一个百分数设置内圈大小，第二个百分数设置外圈大小
      center: ['50%', '50%'], // 设置饼状图位置，第一个百分数调水平位置，第二个百分数调垂直位置
      roseType: 'area',
      itemStyle: {
        borderRadius: 17,
        emphasis: {
          //设置鼠标放置扇形上的样式
          //focus:'series',
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'black'
        }
      },
      label: {
        fontSize: 20
      },
      /*label: {
        normal: {
          position: 'outer',  // 设置标签位置，默认在饼状图外 可选值：'outer' ¦ 'inner（饼状图上）'
          formatter: '{b} {a}: {c} ({d}%)' // {a}指series.name  {b}指series.data的name  {c}指series.data的value  {d}%指这一部分占总数的百分比
        }
      },*/
      labelLine: {
        normal: {
          show: true //设置线是否显示
        }
      },

      data: [
        { value: 1837, name: '原煤' },
        { value: 31, name: '精煤' },
        { value: 49, name: '其他洗煤' },
        { value: 13, name: '型煤' },
        { value: 287, name: '焦炭' },
        { value: 28, name: '焦炉煤气' },
        { value: 39, name: '其他气体' },
        { value: 7, name: '其他焦化产品' },
        { value: 16, name: '原油' },
        { value: 97, name: '汽油' },
        { value: 21, name: '煤油' },
        { value: 163, name: '柴油' },
        { value: 113, name: '燃油' },
        { value: 31, name: '液化石油气' },
        { value: 17, name: '炼厂气' },
        { value: 0, name: '其他石油产品' },
        { value: 33, name: '天然气' }
      ]
    }
  ]
};
window.addEventListener('resize', function () {
  myChart.resize();
});


if (option && typeof option === 'object') {
    myChart.setOption(option);
}